
import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import About from './components/About';
import Menu from './components/Menu';
import MandiMatchmaker from './components/MandiMatchmaker';
import Footer from './components/Footer';

const App: React.FC = () => {
  return (
    <div className="min-h-screen">
      <Header />
      <main>
        <Hero />
        
        {/* Stats Bar */}
        <section className="bg-white py-12 border-b border-stone-100">
          <div className="max-w-7xl mx-auto px-4 grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="text-center border-r border-stone-100 last:border-none">
              <p className="text-3xl font-serif font-black text-red-900">50K+</p>
              <p className="text-[10px] font-bold text-stone-500 uppercase tracking-widest">Happy Customers</p>
            </div>
            <div className="text-center border-r border-stone-100 last:border-none">
              <p className="text-3xl font-serif font-black text-red-900">12</p>
              <p className="text-[10px] font-bold text-stone-500 uppercase tracking-widest">Royal Outlets</p>
            </div>
            <div className="text-center border-r border-stone-100 last:border-none">
              <p className="text-3xl font-serif font-black text-red-900">100%</p>
              <p className="text-[10px] font-bold text-stone-500 uppercase tracking-widest">Halal Certified</p>
            </div>
            <div className="text-center border-r border-stone-100 last:border-none">
              <p className="text-3xl font-serif font-black text-red-900">2012</p>
              <p className="text-[10px] font-bold text-stone-500 uppercase tracking-widest">Established</p>
            </div>
          </div>
        </section>

        <About />
        <MandiMatchmaker />
        <Menu />

        {/* Call to Action Section */}
        <section className="py-24 bg-stone-50 overflow-hidden relative">
          <div className="max-w-7xl mx-auto px-4">
            <div className="bg-amber-500 rounded-[3rem] p-8 md:p-20 flex flex-col md:flex-row items-center justify-between gap-12 relative overflow-hidden shadow-2xl">
              {/* Decorative Circle */}
              <div className="absolute -top-20 -right-20 w-80 h-80 bg-white/10 rounded-full blur-3xl"></div>
              
              <div className="relative z-10 text-center md:text-left">
                <h2 className="font-serif text-4xl md:text-5xl font-black text-red-950 mb-6 leading-tight">
                  Craving for <br/> <span className="underline decoration-red-800 underline-offset-8">The Best Mandi?</span>
                </h2>
                <p className="text-red-950/70 font-medium max-w-sm mb-0">
                  Order now through our website and get a complimentary Mint Lime Cooler on your first order.
                </p>
              </div>

              <div className="relative z-10 flex flex-col sm:flex-row gap-4">
                <button className="bg-red-900 text-white px-10 py-5 rounded-2xl font-black uppercase tracking-widest hover:bg-stone-900 transition-all shadow-xl">
                  Order Online
                </button>
                <button className="bg-white text-red-950 px-10 py-5 rounded-2xl font-black uppercase tracking-widest hover:bg-stone-100 transition-all shadow-lg">
                  Visit Outlet
                </button>
              </div>
            </div>
          </div>
        </section>

      </main>
      <Footer />
    </div>
  );
};

export default App;
