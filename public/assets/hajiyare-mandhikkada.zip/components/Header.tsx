
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-sm border-b border-stone-200 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 h-20 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-12 h-12 bg-red-800 rounded-full flex items-center justify-center text-white font-bold text-xl shadow-lg border-2 border-amber-500">
            HM
          </div>
          <div className="leading-tight">
            <h1 className="font-serif text-xl font-black text-red-900 tracking-tighter uppercase">Hajiyare</h1>
            <p className="text-xs font-bold text-amber-600 tracking-widest uppercase">Mandhikkada</p>
          </div>
        </div>

        <nav className="hidden md:flex items-center gap-8 text-sm font-semibold text-stone-700 uppercase tracking-widest">
          <a href="#hero" className="hover:text-red-700 transition-colors">Home</a>
          <a href="#about" className="hover:text-red-700 transition-colors">Our Story</a>
          <a href="#menu" className="hover:text-red-700 transition-colors">Menu</a>
          <a href="#locations" className="hover:text-red-700 transition-colors">Locations</a>
        </nav>

        <a 
          href="#order" 
          className="bg-red-800 text-white px-6 py-2.5 rounded-full text-xs font-bold uppercase tracking-widest hover:bg-red-700 transition-all transform hover:scale-105 active:scale-95 shadow-md"
        >
          Order Now
        </a>
      </div>
    </header>
  );
};

export default Header;
