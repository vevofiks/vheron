
import React from 'react';

const Hero: React.FC = () => {
  return (
    <section id="hero" className="relative h-[90vh] flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1633945274405-b6c8069047b0?auto=format&fit=crop&w=1920&q=90" 
          alt="Authentic Mandi Spread" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/40 to-transparent"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 w-full">
        <div className="max-w-2xl text-white">
          <span className="inline-block bg-amber-500/90 text-stone-900 px-4 py-1 text-xs font-bold uppercase tracking-widest rounded-full mb-6">
            The King of Arabian Flavours
          </span>
          <h2 className="font-serif text-6xl md:text-8xl font-black leading-tight mb-6 drop-shadow-xl">
            Savour the <br/> <span className="text-amber-400">Royal</span> Tradition.
          </h2>
          <p className="text-lg md:text-xl text-stone-200 mb-10 max-w-lg leading-relaxed font-light">
            Experience the original charcoal-smoked aroma and melt-in-the-mouth meat of Hajiyare's legendary Mandi.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <button className="bg-amber-500 text-stone-900 px-10 py-4 rounded-full font-bold uppercase tracking-widest hover:bg-white transition-all shadow-xl">
              Explore Menu
            </button>
            <button className="border-2 border-white/50 backdrop-blur-sm text-white px-10 py-4 rounded-full font-bold uppercase tracking-widest hover:bg-white hover:text-stone-900 transition-all">
              Find a Table
            </button>
          </div>
        </div>
      </div>

      {/* Decorative Badge */}
      <div className="absolute bottom-10 right-10 hidden lg:block">
        <div className="bg-white p-6 rounded-2xl shadow-2xl border-t-4 border-red-800 max-w-[200px] transform rotate-3">
          <p className="text-red-800 font-serif font-black text-2xl">100%</p>
          <p className="text-stone-600 text-xs font-bold uppercase tracking-widest">Natural Charcoal Smoked</p>
        </div>
      </div>
    </section>
  );
};

export default Hero;
