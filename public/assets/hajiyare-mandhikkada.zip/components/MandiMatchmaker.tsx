
import React, { useState } from 'react';
import { getMandiRecommendation } from '../services/gemini';
import { Recommendation } from '../types';

const MandiMatchmaker: React.FC = () => {
  const [mood, setMood] = useState('');
  const [loading, setLoading] = useState(false);
  const [recommendation, setRecommendation] = useState<Recommendation | null>(null);

  const handleRecommend = async () => {
    if (!mood.trim()) return;
    setLoading(true);
    const result = await getMandiRecommendation(mood);
    setRecommendation(result);
    setLoading(false);
  };

  return (
    <section className="py-24 bg-red-900 text-white overflow-hidden relative">
      {/* Texture Overlay */}
      <div className="absolute inset-0 opacity-10 pointer-events-none" style={{backgroundImage: 'url("https://www.transparenttextures.com/patterns/natural-paper.png")'}}></div>

      <div className="max-w-4xl mx-auto px-4 relative z-10">
        <div className="bg-white/10 backdrop-blur-lg rounded-[2.5rem] p-8 md:p-16 border border-white/20 shadow-2xl">
          <div className="text-center mb-10">
            <h3 className="font-serif text-4xl font-black mb-4">The Mandi Matchmaker</h3>
            <p className="text-red-100 font-light text-lg">Tell us your mood, and our AI will pick your perfect feast.</p>
          </div>

          <div className="flex flex-col md:flex-row gap-4 mb-8">
            <input 
              type="text" 
              placeholder="Ex: 'I'm super hungry and want something really spicy!'"
              value={mood}
              onChange={(e) => setMood(e.target.value)}
              className="flex-1 bg-white/5 border-2 border-white/20 rounded-2xl px-6 py-4 text-white placeholder:text-red-200 outline-none focus:border-amber-500 transition-all"
            />
            <button 
              onClick={handleRecommend}
              disabled={loading}
              className="bg-amber-500 text-red-950 px-8 py-4 rounded-2xl font-black uppercase tracking-widest hover:bg-white transition-all disabled:opacity-50"
            >
              {loading ? 'Consulting Chef...' : 'Match Me'}
            </button>
          </div>

          {recommendation && (
            <div className="bg-white rounded-3xl p-8 text-stone-900 transform animate-in fade-in slide-in-from-bottom-4 duration-500">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center text-red-800">
                  ✨
                </div>
                <div>
                  <p className="text-[10px] font-bold text-red-800 uppercase tracking-widest">Your Perfect Match</p>
                  <h4 className="font-serif text-2xl font-black">{recommendation.dishName}</h4>
                </div>
              </div>
              <p className="text-stone-600 mb-6 italic">"{recommendation.reason}"</p>
              <div className="flex items-center gap-2 text-sm">
                <span className="font-bold text-amber-600">Perfect Pairing:</span>
                <span className="bg-amber-50 px-3 py-1 rounded-full text-amber-800 font-medium">{recommendation.pairing}</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

export default MandiMatchmaker;
