
import React, { useState } from 'react';
import { MENU_ITEMS } from '../constants';

const Menu: React.FC = () => {
  const [filter, setFilter] = useState<'All' | 'Mandi' | 'Sides' | 'Desserts'>('All');

  const filteredItems = filter === 'All' 
    ? MENU_ITEMS 
    : MENU_ITEMS.filter(item => item.category === filter);

  const categories: ('All' | 'Mandi' | 'Sides' | 'Desserts')[] = ['All', 'Mandi', 'Sides', 'Desserts'];

  return (
    <section id="menu" className="py-24 bg-stone-100">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-16">
          <h3 className="font-serif text-4xl md:text-5xl font-black text-red-900 mb-4">A Taste of the Pit</h3>
          <div className="w-24 h-1 bg-amber-500 mx-auto mb-8"></div>
          <p className="text-stone-600 max-w-2xl mx-auto">
            Our secret lies in the spice blend curated over decades and the patient slow-cooking in traditional underground pits.
          </p>
        </div>

        <div className="flex justify-center flex-wrap gap-4 mb-12">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setFilter(cat)}
              className={`px-8 py-2 rounded-full text-xs font-bold uppercase tracking-widest transition-all ${
                filter === cat 
                ? 'bg-red-800 text-white shadow-lg' 
                : 'bg-white text-stone-600 hover:bg-stone-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredItems.map(item => (
            <div key={item.id} className="group bg-white rounded-3xl overflow-hidden shadow-sm hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2">
              <div className="relative h-64 overflow-hidden">
                <img 
                  src={item.image} 
                  alt={item.name}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-md px-4 py-1 rounded-full text-sm font-black text-red-900">
                  {item.price}
                </div>
                {item.spicy && (
                  <div className="absolute top-4 left-4 bg-red-600 text-white px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-tighter">
                    🔥 Spicy
                  </div>
                )}
              </div>
              <div className="p-8">
                <h4 className="font-serif text-xl font-bold text-stone-900 mb-2 group-hover:text-red-800 transition-colors">
                  {item.name}
                </h4>
                <p className="text-stone-500 text-sm leading-relaxed mb-6 line-clamp-2">
                  {item.description}
                </p>
                <button className="w-full border-2 border-stone-100 py-3 rounded-xl text-xs font-bold uppercase tracking-widest text-stone-400 group-hover:border-amber-500 group-hover:text-stone-900 transition-all">
                  Add to Order
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Menu;
