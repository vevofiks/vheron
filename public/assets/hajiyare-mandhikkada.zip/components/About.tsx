
import React from 'react';

const About: React.FC = () => {
  return (
    <section id="about" className="py-24 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex flex-col lg:flex-row items-center gap-16">
          <div className="flex-1 relative">
            <div className="grid grid-cols-2 gap-4">
              <img 
                src="https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format&fit=crop&w=400&q=80" 
                alt="Chef cooking" 
                className="rounded-3xl shadow-lg mt-12"
              />
              <img 
                src="https://images.unsplash.com/photo-1541167760496-1628856ab772?auto=format&fit=crop&w=400&q=80" 
                alt="Spices" 
                className="rounded-3xl shadow-lg"
              />
            </div>
            <div className="absolute -bottom-8 -left-8 bg-red-800 text-white p-8 rounded-3xl shadow-2xl hidden md:block">
              <p className="text-4xl font-serif font-black">25+</p>
              <p className="text-xs font-bold uppercase tracking-widest text-red-200">Years of Authentic Spices</p>
            </div>
          </div>
          <div className="flex-1">
            <span className="text-amber-600 font-bold uppercase tracking-[0.3em] text-xs mb-4 block">Our Heritage</span>
            <h3 className="font-serif text-4xl md:text-5xl font-black text-red-900 mb-8 leading-tight">Beyond just a meal, it's a Royal experience.</h3>
            <p className="text-stone-600 leading-relaxed mb-8">
              Hajiyare Mandhikkada was founded on the belief that authenticity shouldn't be compromised. We import our spices directly from the Hadhramaut region of Yemen to ensure every grain of rice and every bite of meat carries the true spirit of Arabian hospitality.
            </p>
            <div className="space-y-6 mb-10">
              <div className="flex items-start gap-4">
                <div className="w-6 h-6 rounded-full bg-red-100 flex items-center justify-center shrink-0 mt-1">
                  <div className="w-2 h-2 rounded-full bg-red-800"></div>
                </div>
                <div>
                  <h5 className="font-bold text-stone-900 uppercase text-sm tracking-wider mb-1">Traditional Kuzhimandhi</h5>
                  <p className="text-stone-500 text-sm">Cooked in specialized 4-foot deep clay pits for that signature smokey finish.</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="w-6 h-6 rounded-full bg-red-100 flex items-center justify-center shrink-0 mt-1">
                  <div className="w-2 h-2 rounded-full bg-red-800"></div>
                </div>
                <div>
                  <h5 className="font-bold text-stone-900 uppercase text-sm tracking-wider mb-1">Signature Mayo & Chutney</h5>
                  <p className="text-stone-500 text-sm">Hand-whipped garlic mayo and freshly ground tomato-chili chutney served fresh daily.</p>
                </div>
              </div>
            </div>
            <button className="text-red-800 font-black uppercase tracking-widest text-xs border-b-2 border-red-800 pb-2 hover:text-amber-600 hover:border-amber-600 transition-all">
              Discover Our Process
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
