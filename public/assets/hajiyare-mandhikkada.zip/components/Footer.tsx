
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-stone-950 text-stone-400 py-20">
      <div className="max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-20">
          <div className="col-span-1 lg:col-span-1">
             <div className="flex items-center gap-2 mb-8">
              <div className="w-10 h-10 bg-red-800 rounded-full flex items-center justify-center text-white font-bold text-lg shadow-lg">
                HM
              </div>
              <div className="leading-tight">
                <h1 className="font-serif text-lg font-black text-white tracking-tighter uppercase">Hajiyare</h1>
                <p className="text-[10px] font-bold text-amber-500 tracking-widest uppercase">Mandhikkada</p>
              </div>
            </div>
            <p className="text-sm leading-relaxed mb-8">
              Bringing the royal taste of authentic Arabian Mandi to your city. We believe in quality, tradition, and hospitality.
            </p>
            <div className="flex gap-4">
              {['FB', 'IG', 'TW', 'YT'].map(social => (
                <div key={social} className="w-10 h-10 rounded-full bg-stone-900 flex items-center justify-center hover:bg-red-800 hover:text-white transition-all cursor-pointer border border-stone-800">
                  <span className="text-[10px] font-bold">{social}</span>
                </div>
              ))}
            </div>
          </div>

          <div>
            <h5 className="text-white font-bold uppercase tracking-widest text-xs mb-8">Quick Links</h5>
            <ul className="space-y-4 text-sm">
              <li><a href="#" className="hover:text-amber-500 transition-colors">Our Menu</a></li>
              <li><a href="#" className="hover:text-amber-500 transition-colors">Find Locations</a></li>
              <li><a href="#" className="hover:text-amber-500 transition-colors">Franchise Inquiry</a></li>
              <li><a href="#" className="hover:text-amber-500 transition-colors">Careers</a></li>
              <li><a href="#" className="hover:text-amber-500 transition-colors">Contact Us</a></li>
            </ul>
          </div>

          <div>
            <h5 className="text-white font-bold uppercase tracking-widest text-xs mb-8">Our Branches</h5>
            <ul className="space-y-4 text-sm">
              <li>Kozhikode - Beach Road</li>
              <li>Kochi - MG Road</li>
              <li>Trivandrum - Kowdiar</li>
              <li>Dubai - Al Barsha</li>
              <li>Sharjah - Muwaileh</li>
            </ul>
          </div>

          <div>
            <h5 className="text-white font-bold uppercase tracking-widest text-xs mb-8">Newsletter</h5>
            <p className="text-sm mb-6">Get royal updates and special offers in your inbox.</p>
            <div className="flex bg-stone-900 rounded-xl p-1 border border-stone-800 focus-within:border-amber-500 transition-all">
              <input 
                type="email" 
                placeholder="Your email" 
                className="bg-transparent border-none outline-none px-4 py-2 flex-1 text-sm text-white"
              />
              <button className="bg-red-800 text-white px-4 py-2 rounded-lg text-xs font-bold uppercase">Join</button>
            </div>
          </div>
        </div>

        <div className="pt-10 border-t border-stone-900 flex flex-col md:flex-row justify-between items-center gap-6 text-[10px] uppercase tracking-widest font-bold">
          <p>© 2024 Hajiyare Mandhikkada. All Rights Reserved.</p>
          <div className="flex gap-8">
            <a href="#" className="hover:text-white">Privacy Policy</a>
            <a href="#" className="hover:text-white">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
