
import React from 'react';
import { MenuItem } from './types';

export const MENU_ITEMS: MenuItem[] = [
  {
    id: '1',
    name: 'Royal Chicken Mandi',
    description: 'Traditionally smoked rice served with tender, succulent chicken pieces infused with Yemeni spices.',
    price: '₹349',
    category: 'Mandi',
    image: 'https://images.unsplash.com/photo-1593560708920-61dd98c46a4e?auto=format&fit=crop&w=800&q=80',
    spicy: false
  },
  {
    id: '2',
    name: 'Mutton Kuzhimandhi',
    description: 'Premium goat meat slow-cooked in a traditional pit, served over long-grain fragrant basmati rice.',
    price: '₹549',
    category: 'Mandi',
    image: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=800&q=80',
    spicy: true
  },
  {
    id: '3',
    name: 'Peri Peri Alfaham Mandi',
    description: 'Flame-grilled chicken with a spicy African bird-eye chili rub, served with aromatic Mandi rice.',
    price: '₹399',
    category: 'Mandi',
    image: 'https://images.unsplash.com/photo-1567620905732-2d1ec7bb7445?auto=format&fit=crop&w=800&q=80',
    spicy: true
  },
  {
    id: '4',
    name: 'Kunafa with Cheese',
    description: 'Traditional Middle Eastern dessert made with shredded phyllo, soaked in syrup, and layered with cheese.',
    price: '₹220',
    category: 'Desserts',
    image: 'https://images.unsplash.com/photo-1511018556340-d16986a1c194?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '5',
    name: 'Arabian Hummus with Pita',
    description: 'Smooth and creamy chickpea dip topped with extra virgin olive oil and sumac.',
    price: '₹140',
    category: 'Sides',
    image: 'https://images.unsplash.com/photo-1577906030559-3aca3b9c0a4e?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '6',
    name: 'Mint Lime Cooler',
    description: 'Refreshing citrus drink with crushed mint leaves and a hint of ginger.',
    price: '₹80',
    category: 'Beverages',
    image: 'https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?auto=format&fit=crop&w=800&q=80'
  }
];

export const COLORS = {
  primary: '#8B1A1A', // Deep Red
  secondary: '#C49102', // Golden/Amber
  accent: '#1F2937', // Dark Slate
};
