
import { GoogleGenAI, Type } from "@google/genai";
import { Recommendation } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const getMandiRecommendation = async (userMood: string): Promise<Recommendation> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Based on this craving/mood: "${userMood}", recommend a Mandi dish. Options are: Royal Chicken Mandi, Mutton Kuzhimandhi, Peri Peri Alfaham Mandi, or Kunafa if they want dessert.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            dishName: { type: Type.STRING },
            reason: { type: Type.STRING },
            pairing: { type: Type.STRING }
          },
          required: ["dishName", "reason", "pairing"]
        }
      }
    });

    return JSON.parse(response.text || '{}') as Recommendation;
  } catch (error) {
    console.error("Gemini Error:", error);
    return {
      dishName: "Royal Chicken Mandi",
      reason: "It's our signature dish that everyone loves!",
      pairing: "Mint Lime Cooler"
    };
  }
};
