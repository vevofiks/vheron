
export interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: string;
  category: 'Mandi' | 'Sides' | 'Beverages' | 'Desserts';
  image: string;
  spicy?: boolean;
}

export interface Recommendation {
  dishName: string;
  reason: string;
  pairing: string;
}
